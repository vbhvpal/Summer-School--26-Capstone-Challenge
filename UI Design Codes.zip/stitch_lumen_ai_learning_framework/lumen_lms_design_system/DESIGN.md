---
name: Lumen LMS Design System
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#4648d4'
  on-secondary: '#ffffff'
  secondary-container: '#6063ee'
  on-secondary-container: '#fffbff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#2a1700'
  on-tertiary-container: '#b87500'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#e1e0ff'
  secondary-fixed-dim: '#c0c1ff'
  on-secondary-fixed: '#07006c'
  on-secondary-fixed-variant: '#2f2ebe'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Source Serif 4
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Source Serif 4
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Source Serif 4
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  stats-number:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 16px
  container-max: 1280px
---

## Brand & Style
The design system is built on the concept of "Intelligence Augmentation" (IA), blending the traditional rigor of higher education with the fluid, proactive nature of modern AI. The aesthetic is **Corporate Modern** with **Gamified Accents**, creating a professional environment that remains deeply engaging.

The interface prioritizes clarity and focus, using generous whitespace to reduce cognitive load while introducing vibrant, RPG-inspired elements—like high-energy gradients and glowing indicators—to signal achievement and progress. The emotional response should be one of "Empowered Focus": the student feels both the authority of the institution and the excitement of a personalized digital journey.

## Colors
This design system utilizes a structured four-tier palette to balance academic authority with gamified energy.

- **Primary (Deep Academic Blue):** Used for navigation, structural headers, and primary actions to establish trust and hierarchy.
- **Secondary (AI Indigo/Purple):** Representing innovation and AI-driven features. Used for recommendation chips, sparklines, and intelligent insights.
- **Accent (Lumen Amber):** The "Enlightenment" color. Reserved strictly for achievement milestones, XP gains, streaks, and critical progress indicators.
- **Surface & Background:** A systematic range of cool greys (`#F8FAFC` to `#E2E8F0`) provides a canvas that feels clinical yet modern.
- **Progress (Vibrant Teal):** Employed for completion states and "on-track" linear gauges to differentiate steady progress from high-tier amber achievements.

## Typography
The typography strategy employs a "Modern Academic" pairing. **Source Serif 4** provides an authoritative, editorial feel for headlines and module titles, reminiscent of classic scholarly texts. **Inter** handles all functional, body, and UI-specific content, ensuring maximum legibility across complex dashboards and data-heavy interfaces.

- Use **Source Serif 4** for page titles and section headers to ground the experience in academia.
- Use **Inter** for all interactive components, navigation, and instructional text.
- **Stats-number** role is specifically for gamification metrics (XP, Streaks, Grades) to provide high-impact visibility.

## Layout & Spacing
The design system utilizes a **12-column fluid grid** for desktop and a **4-column grid** for mobile. The layout philosophy is centered on "Information Density Control"—using wide gutters and generous margins to prevent the LMS from feeling overwhelming.

- **Desktop:** 24px gutters with 64px outer margins. Content is housed in a max-width container of 1280px to maintain line-length readability.
- **Mobile:** 16px gutters and margins. Sidebars collapse into a bottom navigation bar or a "drawer" for quick access to course modules.
- **Spacing Rhythm:** Use a 4px base unit. Component padding should lean towards the larger side (e.g., 24px or 32px for card internals) to emphasize a "premium" feel.

## Elevation & Depth
This design system uses **Tonal Layers** combined with **Ambient Shadows** to create a structured hierarchy. 

1. **Base:** The background is the lowest level (`#F8FAFC`).
2. **Surface:** Cards and modules use a pure white background with a very soft, diffused shadow (0px 4px 20px rgba(15, 23, 42, 0.05)) to appear lifted.
3. **Overlays:** AI recommendation chips and tooltips use a slight "Secondary" color tint in their shadow (rgba(99, 102, 241, 0.1)) to suggest intelligence and digital depth.
4. **Interactive States:** On hover, cards should lift slightly (6px shadow) and transitions should be fluid (200ms ease-out) to mimic the responsiveness of an intelligent system.

## Shapes
A **Rounded (0.5rem)** logic is applied throughout the system to soften the "institutional" feel and make the software appear approachable.

- **Standard Elements:** Buttons, input fields, and cards use the base 0.5rem (8px) radius.
- **Gamified Elements:** Achievement badges and "XP" pills use `rounded-xl` or full pill shapes to feel more like collectible objects rather than static UI.
- **Progress Gauges:** Radial gauges must have rounded end-caps to maintain the soft, human-centered aesthetic.

## Components

### Progress & Gauges
- **Linear Gauges:** 8px height with a background of `#E2E8F0` and a fill of "Progress Teal."
- **Radial Gauges:** Used in student dashboards for "Overall Completion." Use a thick stroke (12px+) with rounded caps.

### Achievement & Gamification
- **Badges:** Circular or hexagonal shapes with a subtle gradient (Lumen Amber to a lighter gold). Include a "glow" effect (drop shadow) when a badge is newly earned.
- **Streak Indicators:** A pill-shaped component featuring the Lumen Amber color and a flame or "lightbulb" icon to indicate consecutive days of learning.

### AI Recommendation Chips
- Compact, secondary-tinted pills (`#EEF2FF` background, `#6366F1` text).
- Feature a small "Spark" icon to denote an AI-generated suggestion.

### Course Cards
- **Structure:** Image at the top (optional), followed by the "Source Serif 4" title, a linear progress bar, and a "Resume" button.
- **Hover State:** Subtle border color shift to Primary Blue.

### Buttons
- **Primary:** Deep Academic Blue with white text. High contrast, authoritative.
- **Action:** Lumen Amber for "Claim Reward" or "Finish Quiz" to drive engagement.
- **Ghost:** Used for secondary navigation within modules, using a 1px border of `#E2E8F0`.

### Dashboards
- Use "Information Tiles" that group related analytics. Data visualizations should use the Secondary (Indigo) and Progress (Teal) colors exclusively, reserving Amber for goal-reached states.